# Sisgf 

Projeto Desenvolvido utilizando PHP, MySQL, JS e Bootstrap.

Instruçõs para rodar o projeto:

* Configurar o servidor apache para a pasta public

* Criar uma cópia do arquivo env.sample.ini com o nome env.ini

* Preencher o arquivo env.ini de acordo com o seu servidor MySQL
